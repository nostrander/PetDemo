/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petdemo;

/**
 *
 * @author natas
 */
//Pet.java
public class Pet
{
	private String name;
	private int age;
	private double weight;
	private boolean isPet;

        private String petType;
          public String toString()
  {
      			if(isPet)
                      {
                        petType="dog";
                        }
                        else
                        {
                         petType="cat";
                        }
      return("Type:"+petType +" Name: "+name+" Age: "+age+ " years"+"\nWeight: "+weight+" pounds");
  }
        
	public Pet(String initialName) {
		name = initialName;
		age = 0;
		weight = 0;
		isPet = true;
	}

	public Pet(double initialWeight) {
		name = "No name still";
                
		age = 0;
		if (initialWeight < 0) {
			System.out.println("Error: Negative weight");
			System.exit(0);
		} else
			weight = initialWeight;
		isPet = true;
	}

	

	public Pet(String initialName, int ageBegins, double initialWeight, boolean type) {
		name = initialName;
		if (ageBegins < 0 || initialWeight < 0) {
			System.out.println("Erro contains Negative age or weight");
			System.exit(0);
		} else {
			age = ageBegins;
			weight = initialWeight;
		}
		isPet = type;
	}

	public void set(String newName, int newAge, double newWeight, boolean type) {
		name = newName;
		if (newAge < 0 || newWeight < 0) {
			System.out.println("Error: Negative age or 	weight");
			System.exit(0);
		} else {
			age = newAge;
			weight = newWeight;
			isPet = type;
		}
	}

	public double acepromazine()
	{
		if (isPet)
			return (weight / 2.2) * (0.03 / 10);
		else
			return (weight / 2.2) * (0.002 / 10);
	}

	public double carprofen()
		{
			if(isPet)
				return (weight / 2.2) *  (0.5 / 12);

			else
				return (weight / 2.2) *
					   (0.25 / 12);
		}
}