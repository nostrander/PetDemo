/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petdemo;

/**
 *
 * @author natas
 */
import java.text.DecimalFormat;
import java.util.*;

public class PetDemo {

public static void main(String args[]) {

            Pet p = new Pet("Jane Doe");
		System.out.println("No records on your pet name ");
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Please enter the pet's name:");
		String name = keyboard.nextLine();
		System.out.println("Please Enter the pet's type (dog or cat):");
		String choice = keyboard.nextLine();
                boolean isDog;
		if (choice.equalsIgnoreCase("dog"))
			isDog = true;
		else
			isDog = false;
                
                System.out.println("Please enter the pet's age:");
		int age = keyboard.nextInt();
		System.out.println("Please enter the pet's weight:");
		double weight = keyboard.nextDouble();
		keyboard.nextLine();
		p.set(name, age, weight, isDog);

		System.out.println("Records as follows:");
		System.out.println(p);
                        DecimalFormat formattingObject = new DecimalFormat("0.0000");
        String acepDose = formattingObject.format(p.acepromazine());
        String carpDose = formattingObject.format(p.carprofen());
		System.out.println("Carprofen needed: " + carpDose + " ml");
                		System.out.println("Acepromazine needed: " + acepDose + " ml");

	}
}